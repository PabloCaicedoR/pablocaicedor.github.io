## Revealjs Mini Demos

This folder contains the source code for the embedded mini demos used in the Quarto [Revealjs documentation](https://quarto.org/docs/presentation/revealjs/).
